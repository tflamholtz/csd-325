from django.shortcuts import render, HttpResponse

# Create your views here.
# modified to return Flamholtz says Hello!
def home(request):
    return HttpResponse("Flamholtz says Hello!")